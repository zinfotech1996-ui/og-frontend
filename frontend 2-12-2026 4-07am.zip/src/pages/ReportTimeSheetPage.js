import React, { useState, useEffect, useMemo } from 'react';
import axios from 'axios';
import {
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  ChevronRight as ChevronRightIcon,
  Download,
  Users as UsersIcon,
  Briefcase,
  Check,
  Info,
  Calendar
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { useAuth } from '../contexts/AuthContext';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

// Helper function to get week start (Monday)
const getWeekStart = (date) => {
  const d = new Date(date);
  const day = d.getDay();
  const diff = day === 0 ? 6 : day - 1; // Days to subtract to get to Monday
  const monday = new Date(d);
  monday.setDate(d.getDate() - diff); // Subtract to get Monday
  monday.setHours(0, 0, 0, 0); // Reset time to start of day
  return monday;
};

export const ReportTimeSheetPage = () => {
  const { token, user } = useAuth();
  
  // Check admin role using same pattern as DetailedViewPage
  const isAdmin = user?.role === 'admin';

  // State for date navigation - Start week on Monday
  const [currentWeekStart, setCurrentWeekStart] = useState(() => {
    const today = new Date();
    const day = today.getDay();
    const diff = day === 0 ? 6 : day - 1;
    const monday = new Date(today);
    monday.setDate(today.getDate() - diff);
    return monday;
  });
  
  // State for date filter
  const [dateFilter, setDateFilter] = useState('this-week');
  const [showCustomDatePicker, setShowCustomDatePicker] = useState(false);
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');

  // State for filters
  const [selectedUserId, setSelectedUserId] = useState('all');
  const [selectedProjectId, setSelectedProjectId] = useState('all');
  const [selectedTaskId, setSelectedTaskId] = useState('all');

  // State for data
  const [users, setUsers] = useState([]);
  const [projects, setProjects] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [timeEntries, setTimeEntries] = useState([]);
  const [loading, setLoading] = useState(false);

  // State for expanded rows
  const [expandedRows, setExpandedRows] = useState({});

  // Calculate week dates
  const weekDates = useMemo(() => {
    const dates = [];
    for (let i = 0; i < 7; i++) {
      const date = new Date(currentWeekStart);
      date.setDate(currentWeekStart.getDate() + i);
      dates.push(date);
    }
    return dates;
  }, [currentWeekStart]);

  // Format date helper
  const formatDate = (date) => {
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const formatDayName = (date) => {
    return date.toLocaleDateString('en-US', { weekday: 'short' }).toUpperCase();
  };

  // Date filter handler
  const handleDateFilterChange = (value) => {
    setDateFilter(value);
    setShowCustomDatePicker(value === 'custom');
    
    const today = new Date();
    let newWeekStart;
    
    switch (value) {
      case 'today':
        // Set to current day's week start
        newWeekStart = getWeekStart(today);
        setCurrentWeekStart(newWeekStart);
        break;
        
      case 'this-week':
        newWeekStart = getWeekStart(today);
        setCurrentWeekStart(newWeekStart);
        break;
        
      case 'last-week':
        newWeekStart = getWeekStart(today);
        newWeekStart.setDate(newWeekStart.getDate() - 7);
        setCurrentWeekStart(newWeekStart);
        break;
        
      case 'this-month':
        const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
        newWeekStart = getWeekStart(firstDayOfMonth);
        setCurrentWeekStart(newWeekStart);
        break;
        
      case 'last-month':
        const firstDayOfLastMonth = new Date(today.getFullYear(), today.getMonth() - 1, 1);
        newWeekStart = getWeekStart(firstDayOfLastMonth);
        setCurrentWeekStart(newWeekStart);
        break;
        
      case 'custom':
        // Show custom date picker
        break;
        
      default:
        break;
    }
  };
  
  // Apply custom date range
  const handleApplyCustomDate = () => {
    if (customStartDate && customEndDate) {
      const startDate = new Date(customStartDate);
      setCurrentWeekStart(getWeekStart(startDate));
      setShowCustomDatePicker(false);
    }
  };

  // Navigation handlers
  const handlePreviousWeek = () => {
    const newDate = new Date(currentWeekStart);
    newDate.setDate(newDate.getDate() - 7);
    setCurrentWeekStart(newDate);
    setDateFilter('custom');
  };

  const handleNextWeek = () => {
    const newDate = new Date(currentWeekStart);
    newDate.setDate(newDate.getDate() + 7);
    setCurrentWeekStart(newDate);
    setDateFilter('custom');
  };

  // Fetch master data
  useEffect(() => {
    const fetchMasterData = async () => {
      try {
        // Only fetch all users if admin
        if (isAdmin) {
          const usersRes = await axios.get(`${API}/users`, {
            headers: { Authorization: `Bearer ${token}` }
          });
          setUsers(usersRes.data || []);
        } else {
          // For non-admin, only set current user
          if (user) {
            setUsers([{ id: user.id, name: user.name }]);
          }
        }

        // Fetch projects
        const projectsRes = await axios.get(`${API}/projects`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        setProjects(projectsRes.data || []);

        // Fetch tasks
        const tasksRes = await axios.get(`${API}/tasks`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        setTasks(tasksRes.data || []);
      } catch (error) {
        console.error('Error fetching master data:', error);
        // If API fails, at least set current user for non-admin
        if (!isAdmin && user) {
          setUsers([{ id: user.id, name: user.name }]);
        }
      }
    };

    if (token && user) {
      fetchMasterData();
    }
  }, [token, user, isAdmin]);

  // Update selected user when auth state changes
  useEffect(() => {
    if (!isAdmin && user) {
      setSelectedUserId(user.id);
    }
  }, [isAdmin, user]);

  // Fetch time entries
  useEffect(() => {
    const fetchTimeEntries = async () => {
      if (!token || !user) return;

      setLoading(true);
      try {
        const weekEnd = new Date(currentWeekStart);
        weekEnd.setDate(weekEnd.getDate() + 6);

        const params = {
          start_date: currentWeekStart.toISOString().split('T')[0],
          end_date: weekEnd.toISOString().split('T')[0],
        };

        // For non-admin users, always filter by their user ID
        if (!isAdmin) {
          params.user_id = user.id;
        } else if (selectedUserId !== 'all') {
          params.user_id = selectedUserId;
        }

        if (selectedProjectId !== 'all') params.project_id = selectedProjectId;

        const response = await axios.get(`${API}/time-entries`, {
          params,
          headers: { Authorization: `Bearer ${token}` }
        });
        setTimeEntries(response.data || []);
      } catch (error) {
        console.error('Error fetching time entries:', error);
        setTimeEntries([]);
      } finally {
        setLoading(false);
      }
    };

    fetchTimeEntries();
  }, [currentWeekStart, selectedUserId, selectedProjectId, token, user, isAdmin]);

  // Group and aggregate time entries
  const groupedData = useMemo(() => {
    if (!timeEntries.length || !user) return [];

    const grouped = {};

    timeEntries.forEach(entry => {
      const userId = entry.user_id || user.id; // Fallback to current user
      const projectId = entry.project_id || 'no-project';
      const taskId = entry.task_id || 'no-task';
      const entryDate = new Date(entry.date || entry.start_time);

      // Calculate day index based on Monday=0, Sunday=6
      const dayOfWeek = entryDate.getDay();
      const dayIndex = dayOfWeek === 0 ? 6 : dayOfWeek - 1;

      const duration = entry.duration || 0;

      // Initialize user
      if (!grouped[userId]) {
        // Find user name from users array or use current user
        let userName;
        if (userId === user.id) {
          userName = user.name;
        } else {
          const foundUser = users.find(u => u.id === userId);
          userName = foundUser ? foundUser.name : 'Unknown User';
        }

        grouped[userId] = {
          id: userId,
          name: userName,
          projects: {},
          totalHours: Array(7).fill(0),
        };
      }

      // Initialize project
      if (!grouped[userId].projects[projectId]) {
        const project = projects.find(p => p.id === projectId);
        grouped[userId].projects[projectId] = {
          id: projectId,
          name: projectId === 'no-project' ? 'No Project' : (project?.name || `Project ${projectId}`),
          tasks: {},
          totalHours: Array(7).fill(0),
        };
      }

      // Initialize task
      if (!grouped[userId].projects[projectId].tasks[taskId]) {
        const task = tasks.find(t => t.id === taskId);
        grouped[userId].projects[projectId].tasks[taskId] = {
          id: taskId,
          name: taskId === 'no-task' ? 'No Task' : (task?.name || `Task ${taskId}`),
          totalHours: Array(7).fill(0),
        };
      }

      // Add hours
      const hours = duration / 3600;
      grouped[userId].totalHours[dayIndex] += hours;
      grouped[userId].projects[projectId].totalHours[dayIndex] += hours;
      grouped[userId].projects[projectId].tasks[taskId].totalHours[dayIndex] += hours;
    });

    return grouped;
  }, [timeEntries, users, projects, tasks, user]);

  // Calculate grand totals
  const grandTotals = useMemo(() => {
    const totals = Array(7).fill(0);
    Object.values(groupedData).forEach(user => {
      user.totalHours.forEach((hours, index) => {
        totals[index] += hours;
      });
    });
    return totals;
  }, [groupedData]);

  // Format hours display
  const formatHours = (hours) => {
    if (hours === 0) return '0';
    const h = Math.floor(hours);
    const m = Math.round((hours - h) * 60);
    return `${h}:${m.toString().padStart(2, '0')}`;
  };

  // Toggle row expansion
  const toggleRow = (rowId) => {
    setExpandedRows(prev => ({
      ...prev,
      [rowId]: !prev[rowId]
    }));
  };

  // Export handlers
  const handleExportPDF = async () => {
    try {
      const weekEnd = new Date(currentWeekStart);
      weekEnd.setDate(weekEnd.getDate() + 6);

      const params = {
        start_date: currentWeekStart.toISOString().split('T')[0],
        end_date: weekEnd.toISOString().split('T')[0],
      };

      // For non-admin, always use their user ID
      if (!isAdmin) {
        params.user_id = user.id;
      } else if (selectedUserId !== 'all') {
        params.user_id = selectedUserId;
      }

      const response = await axios.get(`${API}/reports/export/pdf`, {
        params,
        responseType: 'blob',
        headers: { Authorization: `Bearer ${token}` }
      });

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `timesheet_${params.start_date}_to_${params.end_date}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      console.error('Error exporting PDF:', error);
    }
  };

  return (
    <div className="min-h-screen">
      <div className="max-w-[1400px] mx-auto p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <h1 className="text-4xl font-bold" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif' }}>
              Timesheet
            </h1>
            <Info className="w-5 h-5 text-gray-400" />
          </div>
          <Button
            onClick={handleExportPDF}
            className="bg-blue-500 hover:bg-blue-600 text-white px-6"
            data-testid="download-pdf-btn"
          >
            <Download className="w-4 h-4 mr-2" />
            Download PDF
          </Button>
        </div>

        {/* Date Navigation */}
        <div className="bg-white rounded-lg border border-gray-200 p-4 mb-6">
          <div className="flex items-center gap-4 flex-wrap">
            <Select value={dateFilter} onValueChange={handleDateFilterChange}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="This week" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="this-week">This week</SelectItem>
                <SelectItem value="last-week">Last week</SelectItem>
                <SelectItem value="this-month">This month</SelectItem>
                <SelectItem value="last-month">Last month</SelectItem>
                <SelectItem value="custom">Custom</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={handlePreviousWeek}
                data-testid="previous-week-btn"
              >
                <ChevronLeft className="w-5 h-5" />
              </Button>

              <div className="text-lg font-medium px-4">
                {formatDate(weekDates[0])} → {formatDate(weekDates[6])}
              </div>

              <Button
                variant="ghost"
                size="icon"
                onClick={handleNextWeek}
                data-testid="next-week-btn"
              >
                <ChevronRight className="w-5 h-5" />
              </Button>
            </div>
          </div>
          
          {/* Custom Date Picker */}
          {showCustomDatePicker && (
            <div className="mt-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
              <div className="flex items-center gap-4 flex-wrap">
                <div className="flex items-center gap-2">
                  <Input
                    type="date"
                    value={customStartDate}
                    onChange={(e) => setCustomStartDate(e.target.value)}
                    className="w-[180px]"
                    placeholder="Start Date"
                  />
                  <span className="text-gray-500">→</span>
                  <Input
                    type="date"
                    value={customEndDate}
                    onChange={(e) => setCustomEndDate(e.target.value)}
                    className="w-[180px]"
                    placeholder="End Date"
                  />
                </div>
                <div className="flex gap-2">
                  <Button 
                    onClick={handleApplyCustomDate}
                    disabled={!customStartDate || !customEndDate}
                    className="bg-blue-500 hover:bg-blue-600 text-white"
                  >
                    Apply
                  </Button>
                  <Button 
                    variant="outline"
                    onClick={() => {
                      setShowCustomDatePicker(false);
                      setDateFilter('this-week');
                      handleDateFilterChange('this-week');
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg border border-gray-200 p-4 mb-6">
          <div className="flex items-center gap-4 flex-wrap">
            <span className="text-sm font-semibold text-gray-600">FILTERS:</span>

            {/* Users Filter - Only show for Admin */}
            {isAdmin && (
              <Select value={selectedUserId} onValueChange={setSelectedUserId}>
                <SelectTrigger className="w-[150px]" data-testid="users-filter">
                  <UsersIcon className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Users" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Users</SelectItem>
                  {users.map(user => (
                    <SelectItem key={user.id} value={user.id}>
                      {user.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}

            {/* Projects Filter */}
            <Select value={selectedProjectId} onValueChange={setSelectedProjectId}>
              <SelectTrigger className="w-[150px]" data-testid="projects-filter">
                <Briefcase className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Projects" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Projects</SelectItem>
                {projects.map(project => (
                  <SelectItem key={project.id} value={project.id}>
                    {project.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Tasks Filter */}
            <Select value={selectedTaskId} onValueChange={setSelectedTaskId}>
              <SelectTrigger className="w-[150px]" data-testid="tasks-filter">
                <Check className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Tasks" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Tasks</SelectItem>
                {tasks.map(task => (
                  <SelectItem key={task.id} value={task.id}>
                    {task.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Table */}
        <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
          {loading ? (
            <div className="p-8 text-center text-gray-500" data-testid="loading-state">Loading...</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full" data-testid="timesheet-table">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider w-64">
                      GRAND TOTAL
                    </th>
                    {weekDates.map((date, index) => (
                      <th key={index} className="px-4 py-3 text-center text-xs font-medium uppercase tracking-wider">
                        <div>{formatDayName(date)}, {formatDate(date).replace(' ', ' ')}</div>
                      </th>
                    ))}
                  </tr>
                  <tr className="bg-gray-50 border-b border-gray-200">
                    <th className="px-6 py-2 text-left text-xs font-medium">
                      Total hours
                    </th>
                    {weekDates.map((_, index) => (
                      <th key={index} className="px-4 py-2 text-center text-xs font-medium">
                        Total hours
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {Object.values(groupedData).map((userRow) => (
                    <React.Fragment key={userRow.id}>
                      {/* User Row */}
                      <tr className="bg-gray-100 hover:bg-gray-200 transition-colors" data-testid={`user-row-${userRow.id}`}>
                        <td className="px-6 py-3 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => toggleRow(`user-${userRow.id}`)}
                              className="text-gray-500 hover:text-gray-700"
                              data-testid={`expand-user-${userRow.id}`}
                            >
                              {expandedRows[`user-${userRow.id}`] ? (
                                <ChevronDown className="w-4 h-4" />
                              ) : (
                                <ChevronRightIcon className="w-4 h-4" />
                              )}
                            </button>
                            <span className="font-medium">{userRow.name} Total</span>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-center font-bold">
                          {formatHours(userRow.totalHours.reduce((a, b) => a + b, 0))}
                        </td>
                        {userRow.totalHours.map((hours, index) => (
                          <td key={index} className="px-4 py-3 text-center">
                            {formatHours(hours)}
                          </td>
                        ))}
                      </tr>

                      {/* Project Rows */}
                      {expandedRows[`user-${userRow.id}`] && Object.values(userRow.projects).map((project) => (
                        <React.Fragment key={`${userRow.id}-${project.id}`}>
                          <tr className="bg-gray-50 hover:bg-gray-100 transition-colors">
                            <td className="px-6 py-3 whitespace-nowrap pl-12">
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={() => toggleRow(`project-${userRow.id}-${project.id}`)}
                                  className="text-gray-500 hover:text-gray-700"
                                >
                                  {expandedRows[`project-${userRow.id}-${project.id}`] ? (
                                    <ChevronDown className="w-4 h-4" />
                                  ) : (
                                    <ChevronRightIcon className="w-4 h-4" />
                                  )}
                                </button>
                                <span className="text-sm">{project.name} Total</span>
                              </div>
                            </td>
                            <td className="px-4 py-3 text-center font-semibold">
                              {formatHours(project.totalHours.reduce((a, b) => a + b, 0))}
                            </td>
                            {project.totalHours.map((hours, index) => (
                              <td key={index} className="px-4 py-3 text-center text-sm">
                                {formatHours(hours)}
                              </td>
                            ))}
                          </tr>

                          {/* Task Rows */}
                          {expandedRows[`project-${userRow.id}-${project.id}`] && Object.values(project.tasks).map((task) => (
                            <tr key={`${userRow.id}-${project.id}-${task.id}`} className="hover:bg-gray-50 transition-colors">
                              <td className="px-6 py-3 whitespace-nowrap pl-20">
                                <span className="text-sm text-gray-600">{task.name}</span>
                              </td>
                              <td className="px-4 py-3 text-center font-medium">
                                {formatHours(task.totalHours.reduce((a, b) => a + b, 0))}
                              </td>
                              {task.totalHours.map((hours, index) => (
                                <td key={index} className="px-4 py-3 text-center text-sm">
                                  {formatHours(hours)}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </React.Fragment>
                      ))}
                    </React.Fragment>
                  ))}

                  {/* Grand Total Row */}
                  <tr className="bg-gray-200 font-bold border-t-2 border-gray-300" data-testid="grand-total-row">
                    <td className="px-6 py-4 whitespace-nowrap">
                      Grand Total
                    </td>
                    <td className="px-4 py-4 text-center">
                      {formatHours(grandTotals.reduce((a, b) => a + b, 0))}
                    </td>
                    {grandTotals.map((hours, index) => (
                      <td key={index} className="px-4 py-4 text-center">
                        {formatHours(hours)}
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
