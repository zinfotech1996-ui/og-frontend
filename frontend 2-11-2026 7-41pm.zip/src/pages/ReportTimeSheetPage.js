import React, { useState, useEffect, useMemo } from 'react';
import axios from 'axios';
import {
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  ChevronRight as ChevronRightIcon,
  Download,
  Users as UsersIcon,
  Folder,
  Briefcase,
  Check,
  Filter,
  Info
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

export const ReportTimeSheetPage = () => {
  // State for date navigation
  const [currentWeekStart, setCurrentWeekStart] = useState(() => {
    const today = new Date();
    const day = today.getDay();
    const diff = today.getDate() - day; // Adjust to Sunday
    return new Date(today.setDate(diff));
  });

  // State for filters
  const [selectedUserId, setSelectedUserId] = useState('all');
  const [selectedClientId, setSelectedClientId] = useState('all');
  const [selectedProjectId, setSelectedProjectId] = useState('all');
  const [selectedTaskId, setSelectedTaskId] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');

  // State for data
  const [users, setUsers] = useState([]);
  const [clients, setClients] = useState([]);
  const [projects, setProjects] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [timeEntries, setTimeEntries] = useState([]);
  const [loading, setLoading] = useState(false);

  // State for expanded rows
  const [expandedRows, setExpandedRows] = useState({});

  // Calculate week dates
  const weekDates = useMemo(() => {
    const dates = [];
    for (let i = 0; i < 7; i++) {
      const date = new Date(currentWeekStart);
      date.setDate(currentWeekStart.getDate() + i);
      dates.push(date);
    }
    return dates;
  }, [currentWeekStart]);

  // Format date helper
  const formatDate = (date) => {
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const formatDayName = (date) => {
    return date.toLocaleDateString('en-US', { weekday: 'short' }).toUpperCase();
  };

  // Navigation handlers
  const handlePreviousWeek = () => {
    const newDate = new Date(currentWeekStart);
    newDate.setDate(newDate.getDate() - 7);
    setCurrentWeekStart(newDate);
  };

  const handleNextWeek = () => {
    const newDate = new Date(currentWeekStart);
    newDate.setDate(newDate.getDate() + 7);
    setCurrentWeekStart(newDate);
  };

  // Fetch master data
  useEffect(() => {
    const fetchMasterData = async () => {
      try {
        // Fetch users
        const usersRes = await axios.get(`${API}/users`);
        setUsers(usersRes.data || []);

        // Fetch projects
        const projectsRes = await axios.get(`${API}/projects`);
        setProjects(projectsRes.data || []);

        // Fetch tasks
        const tasksRes = await axios.get(`${API}/tasks`);
        setTasks(tasksRes.data || []);

        // Note: If you have a clients endpoint, fetch it here
        // const clientsRes = await axios.get(`${API}/clients`);
        // setClients(clientsRes.data || []);
      } catch (error) {
        console.error('Error fetching master data:', error);
      }
    };

    fetchMasterData();
  }, []);

  // Fetch time entries
  useEffect(() => {
    const fetchTimeEntries = async () => {
      setLoading(true);
      try {
        const weekEnd = new Date(currentWeekStart);
        weekEnd.setDate(weekEnd.getDate() + 6);

        const params = {
          start_date: currentWeekStart.toISOString().split('T')[0],
          end_date: weekEnd.toISOString().split('T')[0],
        };

        if (selectedUserId !== 'all') params.user_id = selectedUserId;
        if (selectedProjectId !== 'all') params.project_id = selectedProjectId;

        const response = await axios.get(`${API}/time-entries`, { params });
        setTimeEntries(response.data || []);
      } catch (error) {
        console.error('Error fetching time entries:', error);
        setTimeEntries([]);
      } finally {
        setLoading(false);
      }
    };

    fetchTimeEntries();
  }, [currentWeekStart, selectedUserId, selectedProjectId]);

  // Group and aggregate time entries
  const groupedData = useMemo(() => {
    if (!timeEntries.length) return [];

    const grouped = {};

    timeEntries.forEach(entry => {
      const userId = entry.user_id || 'no-user';
      const clientId = entry.client_id || 'no-client';
      const projectId = entry.project_id || 'no-project';
      const taskId = entry.task_id || 'no-task';
      const entryDate = new Date(entry.date || entry.start_time);
      const dayIndex = entryDate.getDay();
      const duration = entry.duration || 0; // duration in seconds

      // Initialize user
      if (!grouped[userId]) {
        grouped[userId] = {
          id: userId,
          name: users.find(u => u.id === userId)?.name || 'User1',
          clients: {},
          totalHours: Array(7).fill(0),
        };
      }

      // Initialize client
      if (!grouped[userId].clients[clientId]) {
        grouped[userId].clients[clientId] = {
          id: clientId,
          name: clientId === 'no-client' ? '-no client-' : `Client ${clientId}`,
          projects: {},
          totalHours: Array(7).fill(0),
        };
      }

      // Initialize project
      if (!grouped[userId].clients[clientId].projects[projectId]) {
        const project = projects.find(p => p.id === projectId);
        grouped[userId].clients[clientId].projects[projectId] = {
          id: projectId,
          name: projectId === 'no-project' ? '-no project-' : (project?.name || `Project ${projectId}`),
          tasks: {},
          totalHours: Array(7).fill(0),
        };
      }

      // Initialize task
      if (!grouped[userId].clients[clientId].projects[projectId].tasks[taskId]) {
        const task = tasks.find(t => t.id === taskId);
        grouped[userId].clients[clientId].projects[projectId].tasks[taskId] = {
          id: taskId,
          name: taskId === 'no-task' ? '-no task-' : (task?.name || `Task ${taskId}`),
          totalHours: Array(7).fill(0),
        };
      }

      // Add hours
      const hours = duration / 3600; // Convert seconds to hours
      grouped[userId].totalHours[dayIndex] += hours;
      grouped[userId].clients[clientId].totalHours[dayIndex] += hours;
      grouped[userId].clients[clientId].projects[projectId].totalHours[dayIndex] += hours;
      grouped[userId].clients[clientId].projects[projectId].tasks[taskId].totalHours[dayIndex] += hours;
    });

    return grouped;
  }, [timeEntries, users, projects, tasks]);

  // Calculate grand totals
  const grandTotals = useMemo(() => {
    const totals = Array(7).fill(0);
    Object.values(groupedData).forEach(user => {
      user.totalHours.forEach((hours, index) => {
        totals[index] += hours;
      });
    });
    return totals;
  }, [groupedData]);

  // Format hours display
  const formatHours = (hours) => {
    if (hours === 0) return '0';
    const h = Math.floor(hours);
    const m = Math.round((hours - h) * 60);
    return `${h}:${m.toString().padStart(2, '0')}`;
  };

  // Toggle row expansion
  const toggleRow = (rowId) => {
    setExpandedRows(prev => ({
      ...prev,
      [rowId]: !prev[rowId]
    }));
  };

  // Export handlers
  const handleExportCSV = async () => {
    try {
      const weekEnd = new Date(currentWeekStart);
      weekEnd.setDate(weekEnd.getDate() + 6);

      const params = {
        start_date: currentWeekStart.toISOString().split('T')[0],
        end_date: weekEnd.toISOString().split('T')[0],
      };

      if (selectedUserId !== 'all') params.user_id = selectedUserId;

      const response = await axios.get(`${API}/reports/export/csv`, {
        params,
        responseType: 'blob'
      });

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `timesheet_${params.start_date}_to_${params.end_date}.csv`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      console.error('Error exporting CSV:', error);
    }
  };

  const handleExportXLS = () => {
    // For XLS export, you might use a library like xlsx or export as CSV
    handleExportCSV();
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-[1400px] mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <h1 className="text-4xl font-bold" style={{ fontFamily: 'Plus Jakarta Sans, sans-serif' }}>
              Timesheet
            </h1>
            <Info className="w-5 h-5 text-gray-400" />
          </div>
          <Button
            onClick={handleExportXLS}
            className="bg-blue-500 hover:bg-blue-600 text-white px-6"
          >
            <Download className="w-4 h-4 mr-2" />
            Download XLS
          </Button>
        </div>

        {/* Date Navigation */}
        <div className="bg-white rounded-lg border border-gray-200 p-4 mb-6">
          <div className="flex items-center gap-4">
            <Select defaultValue="this-week">
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="This week" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="this-week">This week</SelectItem>
                <SelectItem value="last-week">Last week</SelectItem>
                <SelectItem value="this-month">This month</SelectItem>
                <SelectItem value="last-month">Last month</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={handlePreviousWeek}
              >
                <ChevronLeft className="w-5 h-5" />
              </Button>

              <div className="text-lg font-medium px-4">
                {formatDate(weekDates[0])} → {formatDate(weekDates[6])}
              </div>

              <Button
                variant="ghost"
                size="icon"
                onClick={handleNextWeek}
              >
                <ChevronRight className="w-5 h-5" />
              </Button>
            </div>

            <div className="ml-auto flex items-center gap-2 text-sm text-gray-600">
              <Briefcase className="w-4 h-4" />
              Edit columns: 6
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg border border-gray-200 p-4 mb-6">
          <div className="flex items-center gap-4 flex-wrap">
            <span className="text-sm font-semibold text-gray-600">FILTERS:</span>

            {/* Users Filter */}
            <Select value={selectedUserId} onValueChange={setSelectedUserId}>
              <SelectTrigger className="w-[150px]">
                <UsersIcon className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Users" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Users</SelectItem>
                {users.map(user => (
                  <SelectItem key={user.id} value={user.id}>
                    {user.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Clients Filter */}
            <Select value={selectedClientId} onValueChange={setSelectedClientId}>
              <SelectTrigger className="w-[150px]">
                <Folder className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Clients" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Clients</SelectItem>
                {clients.map(client => (
                  <SelectItem key={client.id} value={client.id}>
                    {client.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Projects Filter */}
            <Select value={selectedProjectId} onValueChange={setSelectedProjectId}>
              <SelectTrigger className="w-[150px]">
                <Briefcase className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Projects" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Projects</SelectItem>
                {projects.map(project => (
                  <SelectItem key={project.id} value={project.id}>
                    {project.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Tasks Filter */}
            <Select value={selectedTaskId} onValueChange={setSelectedTaskId}>
              <SelectTrigger className="w-[150px]">
                <Check className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Tasks" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Tasks</SelectItem>
                {tasks.map(task => (
                  <SelectItem key={task.id} value={task.id}>
                    {task.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Status Filter */}
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="w-[150px]">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Status: All" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Status: All</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Table */}
        <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
          {loading ? (
            <div className="p-8 text-center text-gray-500">Loading...</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-64">
                      GRAND TOTAL
                    </th>
                    {weekDates.map((date, index) => (
                      <th key={index} className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                        <div>{formatDayName(date)}, {formatDate(date).replace(' ', ' ')}</div>
                      </th>
                    ))}
                  </tr>
                  <tr className="bg-gray-50 border-b border-gray-200">
                    <th className="px-6 py-2 text-left text-xs font-medium text-gray-400">
                      Total hours
                    </th>
                    {weekDates.map((_, index) => (
                      <th key={index} className="px-4 py-2 text-center text-xs font-medium text-gray-400">
                        Total hours
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {Object.values(groupedData).map((user) => (
                    <React.Fragment key={user.id}>
                      {/* User Row */}
                      <tr className="bg-gray-100 hover:bg-gray-200 transition-colors">
                        <td className="px-6 py-3 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => toggleRow(`user-${user.id}`)}
                              className="text-gray-500 hover:text-gray-700"
                            >
                              {expandedRows[`user-${user.id}`] ? (
                                <ChevronDown className="w-4 h-4" />
                              ) : (
                                <ChevronRightIcon className="w-4 h-4" />
                              )}
                            </button>
                            <span className="font-medium">{user.name} Total</span>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-center font-bold">
                          {formatHours(user.totalHours.reduce((a, b) => a + b, 0))}
                        </td>
                        {user.totalHours.map((hours, index) => (
                          <td key={index} className="px-4 py-3 text-center">
                            {formatHours(hours)}
                          </td>
                        ))}
                      </tr>

                      {/* Client Rows */}
                      {expandedRows[`user-${user.id}`] && Object.values(user.clients).map((client) => (
                        <React.Fragment key={`${user.id}-${client.id}`}>
                          <tr className="bg-gray-50 hover:bg-gray-100 transition-colors">
                            <td className="px-6 py-3 whitespace-nowrap pl-12">
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={() => toggleRow(`client-${user.id}-${client.id}`)}
                                  className="text-gray-500 hover:text-gray-700"
                                >
                                  {expandedRows[`client-${user.id}-${client.id}`] ? (
                                    <ChevronDown className="w-4 h-4" />
                                  ) : (
                                    <ChevronRightIcon className="w-4 h-4" />
                                  )}
                                </button>
                                <span className="text-sm">{client.name} Total</span>
                              </div>
                            </td>
                            <td className="px-4 py-3 text-center font-semibold">
                              {formatHours(client.totalHours.reduce((a, b) => a + b, 0))}
                            </td>
                            {client.totalHours.map((hours, index) => (
                              <td key={index} className="px-4 py-3 text-center text-sm">
                                {formatHours(hours)}
                              </td>
                            ))}
                          </tr>

                          {/* Project Rows */}
                          {expandedRows[`client-${user.id}-${client.id}`] && Object.values(client.projects).map((project) => (
                            <React.Fragment key={`${user.id}-${client.id}-${project.id}`}>
                              <tr className="hover:bg-gray-50 transition-colors">
                                <td className="px-6 py-3 whitespace-nowrap pl-20">
                                  <div className="flex items-center gap-2">
                                    <button
                                      onClick={() => toggleRow(`project-${user.id}-${client.id}-${project.id}`)}
                                      className="text-gray-500 hover:text-gray-700"
                                    >
                                      {expandedRows[`project-${user.id}-${client.id}-${project.id}`] ? (
                                        <ChevronDown className="w-4 h-4" />
                                      ) : (
                                        <ChevronRightIcon className="w-4 h-4" />
                                      )}
                                    </button>
                                    <span className="text-sm">{project.name} Total</span>
                                  </div>
                                </td>
                                <td className="px-4 py-3 text-center font-semibold">
                                  {formatHours(project.totalHours.reduce((a, b) => a + b, 0))}
                                </td>
                                {project.totalHours.map((hours, index) => (
                                  <td key={index} className="px-4 py-3 text-center text-sm">
                                    {formatHours(hours)}
                                  </td>
                                ))}
                              </tr>

                              {/* Task Rows */}
                              {expandedRows[`project-${user.id}-${client.id}-${project.id}`] && Object.values(project.tasks).map((task) => (
                                <tr key={`${user.id}-${client.id}-${project.id}-${task.id}`} className="hover:bg-gray-50 transition-colors">
                                  <td className="px-6 py-3 whitespace-nowrap pl-28">
                                    <span className="text-sm text-gray-600">{task.name}</span>
                                  </td>
                                  <td className="px-4 py-3 text-center font-medium">
                                    {formatHours(task.totalHours.reduce((a, b) => a + b, 0))}
                                  </td>
                                  {task.totalHours.map((hours, index) => (
                                    <td key={index} className="px-4 py-3 text-center text-sm">
                                      {formatHours(hours)}
                                    </td>
                                  ))}
                                </tr>
                              ))}
                            </React.Fragment>
                          ))}
                        </React.Fragment>
                      ))}
                    </React.Fragment>
                  ))}

                  {/* Grand Total Row */}
                  <tr className="bg-gray-200 font-bold border-t-2 border-gray-300">
                    <td className="px-6 py-4 whitespace-nowrap">
                      Grand Total
                    </td>
                    <td className="px-4 py-4 text-center">
                      {formatHours(grandTotals.reduce((a, b) => a + b, 0))}
                    </td>
                    {grandTotals.map((hours, index) => (
                      <td key={index} className="px-4 py-4 text-center">
                        {formatHours(hours)}
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
